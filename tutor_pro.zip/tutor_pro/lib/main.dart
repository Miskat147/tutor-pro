import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'pages.dart';
import 'ui.dart';

void main() => runApp(const TutorApp());

class TutorApp extends StatelessWidget {
  const TutorApp({super.key});
  @override
  Widget build(BuildContext context) {
    final base = ThemeData(
      brightness: Brightness.dark,
      useMaterial3: true,
      colorScheme: const ColorScheme.dark(primary: K.gold, surface: K.card, onPrimary: K.bg),
      scaffoldBackgroundColor: K.bg,
    );
    return MaterialApp(
      title: 'টিউটর প্রো',
      debugShowCheckedModeBanner: false,
      theme: base.copyWith(
        textTheme: GoogleFonts.hindSiliguriTextTheme(base.textTheme),
        chipTheme: const ChipThemeData(
          backgroundColor: K.glass,
          selectedColor: Color(0x44E8C26B),
          side: BorderSide(color: K.line),
          showCheckmark: false,
        ),
      ),
      home: const Shell(),
    );
  }
}

class Shell extends StatefulWidget {
  const Shell({super.key});
  @override
  State<Shell> createState() => _ShellState();
}

class _ShellState extends State<Shell> {
  int i = 0;
  static const tabs = [
    (Icons.space_dashboard_rounded, 'হোম'),
    (Icons.school_rounded, 'ছাত্র'),
    (Icons.account_balance_wallet_rounded, 'ফি'),
    (Icons.menu_book_rounded, 'ক্লাস'),
  ];

  @override
  Widget build(BuildContext context) => Scaffold(
        extendBody: true,
        body: Container(
          decoration: const BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [Color(0xFF111A3A), K.bg, Color(0xFF160F2B)],
            ),
          ),
          child: SafeArea(
            bottom: false,
            child: IndexedStack(index: i, children: const [Dash(), Students(), Fees(), Classes()]),
          ),
        ),
        bottomNavigationBar: Padding(
          padding: const EdgeInsets.fromLTRB(20, 0, 20, 16),
          child: Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: const Color(0xF2141B30),
              borderRadius: BorderRadius.circular(28),
              border: Border.all(color: K.line),
            ),
            child: Row(children: [
              for (var k = 0; k < tabs.length; k++)
                Expanded(
                  child: GestureDetector(
                    behavior: HitTestBehavior.opaque,
                    onTap: () => setState(() => i = k),
                    child: AnimatedContainer(
                      duration: const Duration(milliseconds: 250),
                      padding: const EdgeInsets.symmetric(vertical: 12),
                      decoration: BoxDecoration(
                        color: i == k ? K.gold : Colors.transparent,
                        borderRadius: BorderRadius.circular(20),
                      ),
                      child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                        Icon(tabs[k].$1, size: 20, color: i == k ? K.bg : K.dim),
                        if (i == k) ...[
                          const SizedBox(width: 6),
                          Text(tabs[k].$2, style: const TextStyle(color: K.bg, fontWeight: FontWeight.w800)),
                        ],
                      ]),
                    ),
                  ),
                ),
            ]),
          ),
        ),
      );
}
