import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import 'db.dart';
import 'ui.dart';

// ───────────── হোম / ড্যাশবোর্ড ─────────────
class Dash extends StatelessWidget {
  const Dash({super.key});

  Future<Map<String, dynamic>> load() async {
    final now = DateTime.now();
    final st = await DB.q('SELECT * FROM students ORDER BY name');
    final rows = await DB.q('SELECT studentId, SUM(amount) s FROM payments WHERE month=? GROUP BY studentId', [ym(now)]);
    final paid = {for (final r in rows) r['studentId'] as int: (r['s'] as num).toDouble()};
    double collected = 0, due = 0;
    paid.forEach((k, v) => collected += v);
    for (final s in st) {
      final fee = (s['fee'] as num).toDouble();
      due += math.max(0.0, fee - (paid[s['id']] ?? 0.0));
    }
    final bars = <MapEntry<String, double>>[];
    for (var i = 5; i >= 0; i--) {
      final d = DateTime(now.year, now.month - i);
      final r = await DB.q('SELECT COALESCE(SUM(amount),0) s FROM payments WHERE month=?', [ym(d)]);
      bars.add(MapEntry(monthShort[d.month - 1], (r.first['s'] as num).toDouble()));
    }
    final today = st.where((s) => ((s['days'] as String?) ?? '').contains(todayWd())).toList();
    return {'collected': collected, 'due': due, 'count': st.length, 'bars': bars, 'today': today};
  }

  Widget stat(String l, String v, Color col) => Expanded(
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(l, style: kDim),
          const SizedBox(height: 2),
          Text(v, style: TextStyle(color: col, fontSize: 19, fontWeight: FontWeight.w700)),
        ]),
      );

  @override
  Widget build(BuildContext context) => Live<Map<String, dynamic>>(
        load: load,
        builder: (c, d) {
          final bars = d['bars'] as List<MapEntry<String, double>>;
          final today = d['today'] as List<Map<String, dynamic>>;
          final mx = bars.fold<double>(1, (a, b) => math.max(a, b.value));
          final now = DateTime.now();
          return ListView(padding: const EdgeInsets.fromLTRB(20, 20, 20, 110), children: [
            const Text('আসসালামু আলাইকুম 👋', style: TextStyle(color: K.dim, fontSize: 15)),
            const SizedBox(height: 4),
            Text('${bn(now.day)} ${monthNames[now.month - 1]} ${bn(now.year)}',
                style: const TextStyle(fontSize: 26, fontWeight: FontWeight.w800)),
            const SizedBox(height: 18),
            Glass(
              pad: const EdgeInsets.all(22),
              grad: const LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [Color(0xFF26335F), Color(0xFF1A1F3D)],
              ),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                const Text('এই মাসে আদায়', style: kDim),
                TweenAnimationBuilder<double>(
                  tween: Tween(begin: 0, end: d['collected'] as double),
                  duration: const Duration(milliseconds: 900),
                  curve: Curves.easeOutCubic,
                  builder: (_, v, __) => Text(taka(v),
                      style: const TextStyle(color: K.gold, fontSize: 38, fontWeight: FontWeight.w800)),
                ),
                const SizedBox(height: 16),
                Row(children: [
                  stat('বাকি আছে', taka(d['due'] as double), K.rose),
                  stat('মোট স্টুডেন্ট', bn(d['count']), K.mint),
                ]),
              ]),
            ),
            const SizedBox(height: 16),
            Glass(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                const Text('গত ৬ মাসের আয়', style: kH),
                const SizedBox(height: 16),
                SizedBox(
                  height: 120,
                  child: Row(crossAxisAlignment: CrossAxisAlignment.end, children: [
                    for (final b in bars)
                      Expanded(
                        child: Column(mainAxisAlignment: MainAxisAlignment.end, children: [
                          TweenAnimationBuilder<double>(
                            tween: Tween(begin: 0, end: b.value / mx),
                            duration: const Duration(milliseconds: 800),
                            curve: Curves.easeOutCubic,
                            builder: (_, v, __) => Container(
                              height: 80 * v + 4,
                              margin: const EdgeInsets.symmetric(horizontal: 6),
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(8),
                                gradient: const LinearGradient(
                                  begin: Alignment.bottomCenter,
                                  end: Alignment.topCenter,
                                  colors: [Color(0x66E8C26B), K.gold],
                                ),
                              ),
                            ),
                          ),
                          const SizedBox(height: 6),
                          Text(b.key, style: const TextStyle(color: K.dim, fontSize: 11)),
                        ]),
                      ),
                  ]),
                ),
              ]),
            ),
            const SizedBox(height: 22),
            const Text('আজকের ক্লাস', style: kH),
            const SizedBox(height: 10),
            if (today.isEmpty)
              const Glass(child: Text('আজ কোনো ক্লাস নেই 🎉', style: kDim))
            else
              for (final s in today)
                Padding(
                  padding: const EdgeInsets.only(bottom: 10),
                  child: Glass(
                    child: Row(children: [
                      Avatar(s['name'] as String),
                      const SizedBox(width: 14),
                      Expanded(
                        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                          Text(s['name'] as String, style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 16)),
                          Text('${s['cls'] ?? ''} • ${s['subjects'] ?? ''}', style: kDim),
                        ]),
                      ),
                    ]),
                  ),
                ),
          ]);
        },
      );
}

class Avatar extends StatelessWidget {
  final String name;
  const Avatar(this.name, {super.key});
  @override
  Widget build(BuildContext context) => Container(
        width: 46,
        height: 46,
        alignment: Alignment.center,
        decoration: const BoxDecoration(
          shape: BoxShape.circle,
          gradient: LinearGradient(colors: [Color(0xFFF6DE97), Color(0xFFC9A04A)]),
        ),
        child: Text(name.characters.first, style: const TextStyle(color: K.bg, fontWeight: FontWeight.w800, fontSize: 18)),
      );
}

// ───────────── স্টুডেন্ট ─────────────
void studentForm(BuildContext c, [Map<String, dynamic>? s]) {
  final n = TextEditingController(text: s?['name']);
  final cl = TextEditingController(text: s?['cls']);
  final ph = TextEditingController(text: s?['phone']);
  final sb = TextEditingController(text: s?['subjects']);
  final fee = TextEditingController(text: s == null ? '' : (s['fee'] as num).round().toString());
  final days = <String>{...((s?['days'] as String? ?? '').split(',').where((e) => e.isNotEmpty))};
  sheet(
    c,
    (ctx) => StatefulBuilder(
      builder: (ctx, set) => Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(s == null ? 'নতুন স্টুডেন্ট' : 'তথ্য সম্পাদনা', style: kH),
        const SizedBox(height: 16),
        field(n, 'নাম'),
        field(cl, 'ক্লাস'),
        field(ph, 'অভিভাবকের ফোন', kb: TextInputType.phone),
        field(sb, 'বিষয়'),
        field(fee, 'মাসিক ফি (৳)', kb: TextInputType.number),
        const Text('পড়ানোর দিন', style: kDim),
        const SizedBox(height: 8),
        Wrap(spacing: 8, children: [
          for (final d in dayNames)
            FilterChip(
              label: Text(d),
              selected: days.contains(d),
              onSelected: (v) => set(() {
                if (v) {
                  days.add(d);
                } else {
                  days.remove(d);
                }
              }),
            ),
        ]),
        const SizedBox(height: 18),
        GoldBtn(
          label: 'সংরক্ষণ করুন',
          onTap: () async {
            if (n.text.trim().isEmpty) return;
            final v = <String, Object?>{
              'name': n.text.trim(),
              'cls': cl.text.trim(),
              'phone': ph.text.trim(),
              'subjects': sb.text.trim(),
              'days': days.join(','),
              'fee': double.tryParse(fee.text.trim()) ?? 0,
            };
            if (s == null) {
              await DB.ins('students', v);
            } else {
              await DB.upd('students', v, s['id'] as int);
            }
            refresh();
            if (ctx.mounted) Navigator.pop(ctx);
          },
        ),
      ]),
    ),
  );
}

Widget addBtn(VoidCallback f) => Container(
      decoration: const BoxDecoration(shape: BoxShape.circle, color: K.gold),
      child: IconButton(onPressed: f, icon: const Icon(Icons.add_rounded, color: K.bg)),
    );

class Students extends StatefulWidget {
  const Students({super.key});
  @override
  State<Students> createState() => _StudentsState();
}

class _StudentsState extends State<Students> {
  String q = '';
  @override
  Widget build(BuildContext context) => Column(children: [
        head('স্টুডেন্ট', trail: addBtn(() => studentForm(context))),
        Padding(
          padding: const EdgeInsets.fromLTRB(20, 0, 20, 12),
          child: TextField(
            onChanged: (v) => setState(() => q = v),
            decoration: InputDecoration(
              hintText: 'নাম দিয়ে খুঁজুন',
              prefixIcon: const Icon(Icons.search_rounded),
              filled: true,
              fillColor: K.glass,
              border: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: BorderSide.none),
            ),
          ),
        ),
        Expanded(
          child: Live<List<Map<String, dynamic>>>(
            load: () => DB.q('SELECT * FROM students WHERE name LIKE ? ORDER BY name', ['%$q%']),
            builder: (c, l) => l.isEmpty
                ? empty(Icons.school_rounded, 'কোনো স্টুডেন্ট নেই')
                : ListView.separated(
                    padding: const EdgeInsets.fromLTRB(20, 4, 20, 110),
                    itemCount: l.length,
                    separatorBuilder: (_, __) => const SizedBox(height: 10),
                    itemBuilder: (_, i) {
                      final s = l[i];
                      return Dismissible(
                        key: ValueKey(s['id']),
                        direction: DismissDirection.endToStart,
                        confirmDismiss: (_) => confirm(c, '${s['name']}-কে মুছে ফেলবেন?'),
                        onDismissed: (_) async {
                          await DB.del('students', s['id'] as int);
                          refresh();
                        },
                        background: Container(
                          alignment: Alignment.centerRight,
                          padding: const EdgeInsets.only(right: 24),
                          decoration: BoxDecoration(color: K.rose.withAlpha(60), borderRadius: BorderRadius.circular(22)),
                          child: const Icon(Icons.delete_rounded, color: K.rose),
                        ),
                        child: Glass(
                          onTap: () => studentForm(c, s),
                          child: Row(children: [
                            Avatar(s['name'] as String),
                            const SizedBox(width: 14),
                            Expanded(
                              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                                Text(s['name'] as String, style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 16)),
                                Text('${s['cls'] ?? ''} • ${s['subjects'] ?? ''}', style: kDim),
                              ]),
                            ),
                            Text(taka(s['fee'] as num), style: const TextStyle(color: K.gold, fontWeight: FontWeight.w700)),
                          ]),
                        ),
                      );
                    },
                  ),
          ),
        ),
      ]);
}

// ───────────── ফি ও রিমাইন্ডার ─────────────
class Fees extends StatefulWidget {
  const Fees({super.key});
  @override
  State<Fees> createState() => _FeesState();
}

class _FeesState extends State<Fees> {
  DateTime m = DateTime(DateTime.now().year, DateTime.now().month);

  Future<List<Map<String, dynamic>>> load() => DB.q(
      'SELECT s.*, COALESCE((SELECT SUM(amount) FROM payments WHERE studentId=s.id AND month=?),0) paid FROM students s ORDER BY s.name',
      [ym(m)]);

  void pay(Map<String, dynamic> s, double due) {
    final a = TextEditingController(text: due.round().toString());
    sheet(
      context,
      (ctx) => Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text('${s['name']} • ${monthLabel(m)}', style: kH),
        const SizedBox(height: 16),
        field(a, 'পরিমাণ (৳)', kb: TextInputType.number),
        GoldBtn(
          label: 'পেমেন্ট নিশ্চিত করুন',
          onTap: () async {
            final v = double.tryParse(a.text.trim()) ?? 0;
            if (v <= 0) return;
            await DB.ins('payments', {'studentId': s['id'], 'amount': v, 'month': ym(m), 'date': ymd(DateTime.now())});
            refresh();
            if (ctx.mounted) Navigator.pop(ctx);
          },
        ),
      ]),
    );
  }

  Future<void> remind(Map<String, dynamic> s, double due) async {
    var p = (s['phone'] as String).replaceAll(RegExp(r'[^0-9]'), '');
    if (p.startsWith('0')) p = '88$p';
    final msg = 'আসসালামু আলাইকুম, ${s['name']}-এর ${monthLabel(m)} মাসের টিউশন ফি ${taka(due)} বাকি আছে। অনুগ্রহ করে পরিশোধ করবেন। ধন্যবাদ।';
    await launchUrl(Uri.https('wa.me', '/$p', {'text': msg}), mode: LaunchMode.externalApplication);
  }

  @override
  Widget build(BuildContext context) => Column(children: [
        head('ফি',
            trail: Row(children: [
              IconButton(onPressed: () => setState(() => m = DateTime(m.year, m.month - 1)), icon: const Icon(Icons.chevron_left_rounded)),
              Text(monthLabel(m), style: const TextStyle(fontWeight: FontWeight.w600)),
              IconButton(onPressed: () => setState(() => m = DateTime(m.year, m.month + 1)), icon: const Icon(Icons.chevron_right_rounded)),
            ])),
        Expanded(
          child: Live<List<Map<String, dynamic>>>(
            load: load,
            builder: (c, l) => l.isEmpty
                ? empty(Icons.account_balance_wallet_rounded, 'আগে স্টুডেন্ট যোগ করুন')
                : ListView.separated(
                    padding: const EdgeInsets.fromLTRB(20, 4, 20, 110),
                    itemCount: l.length,
                    separatorBuilder: (_, __) => const SizedBox(height: 10),
                    itemBuilder: (_, i) {
                      final s = l[i];
                      final fee = (s['fee'] as num).toDouble(), paid = (s['paid'] as num).toDouble();
                      final due = fee - paid;
                      final ok = due <= 0;
                      return Glass(
                        child: Row(children: [
                          Expanded(
                            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                              Text(s['name'] as String, style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 16)),
                              const SizedBox(height: 4),
                              Text('${taka(paid)} / ${taka(fee)}', style: kDim),
                            ]),
                          ),
                          if (ok) pill('পরিশোধিত', K.mint) else pill(paid > 0 ? 'আংশিক' : 'বাকি', paid > 0 ? K.gold : K.rose),
                          if (!ok) IconButton(onPressed: () => pay(s, due), icon: const Icon(Icons.payments_rounded, color: K.gold)),
                          if (!ok && ((s['phone'] as String?) ?? '').isNotEmpty)
                            IconButton(onPressed: () => remind(s, due), icon: const Icon(Icons.chat_rounded, color: K.mint)),
                        ]),
                      );
                    },
                  ),
          ),
        ),
      ]);
}

// ───────────── ক্লাস লগ ─────────────
Future<void> lessonForm(BuildContext c) async {
  final st = await DB.q('SELECT id, name FROM students ORDER BY name');
  if (!c.mounted) return;
  if (st.isEmpty) {
    ScaffoldMessenger.of(c).showSnackBar(const SnackBar(content: Text('আগে একজন স্টুডেন্ট যোগ করুন')));
    return;
  }
  int sel = st.first['id'] as int;
  final tp = TextEditingController(), hw = TextEditingController();
  sheet(
    c,
    (ctx) => StatefulBuilder(
      builder: (ctx, set) => Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Text('আজকের ক্লাস লিখুন', style: kH),
        const SizedBox(height: 14),
        Wrap(spacing: 8, runSpacing: 4, children: [
          for (final s in st)
            ChoiceChip(
              label: Text(s['name'] as String),
              selected: sel == s['id'],
              onSelected: (_) => set(() => sel = s['id'] as int),
            ),
        ]),
        const SizedBox(height: 14),
        field(tp, 'আজকের টপিক'),
        field(hw, 'হোমওয়ার্ক'),
        GoldBtn(
          label: 'সংরক্ষণ করুন',
          onTap: () async {
            await DB.ins('lessons', {'studentId': sel, 'date': ymd(DateTime.now()), 'topic': tp.text.trim(), 'homework': hw.text.trim()});
            refresh();
            if (ctx.mounted) Navigator.pop(ctx);
          },
        ),
      ]),
    ),
  );
}

class Classes extends StatelessWidget {
  const Classes({super.key});
  @override
  Widget build(BuildContext context) => Column(children: [
        head('ক্লাস লগ', trail: addBtn(() => lessonForm(context))),
        Expanded(
          child: Live<List<Map<String, dynamic>>>(
            load: () => DB.q('SELECT l.*, s.name FROM lessons l JOIN students s ON s.id=l.studentId ORDER BY l.date DESC, l.id DESC LIMIT 60'),
            builder: (c, l) => l.isEmpty
                ? empty(Icons.menu_book_rounded, 'এখনো কোনো ক্লাস লেখা হয়নি')
                : ListView.separated(
                    padding: const EdgeInsets.fromLTRB(20, 4, 20, 110),
                    itemCount: l.length,
                    separatorBuilder: (_, __) => const SizedBox(height: 10),
                    itemBuilder: (_, i) {
                      final x = l[i];
                      return Dismissible(
                        key: ValueKey(x['id']),
                        direction: DismissDirection.endToStart,
                        onDismissed: (_) async {
                          await DB.del('lessons', x['id'] as int);
                          refresh();
                        },
                        background: Container(
                          alignment: Alignment.centerRight,
                          padding: const EdgeInsets.only(right: 24),
                          decoration: BoxDecoration(color: K.rose.withAlpha(60), borderRadius: BorderRadius.circular(22)),
                          child: const Icon(Icons.delete_rounded, color: K.rose),
                        ),
                        child: Glass(
                          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                            Row(children: [
                              Expanded(child: Text(x['name'] as String, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 16))),
                              Text(bn(x['date']), style: kDim),
                            ]),
                            const SizedBox(height: 6),
                            Text('📖 ${x['topic'] ?? ''}'),
                            if (((x['homework'] as String?) ?? '').isNotEmpty) Text('✏️ ${x['homework']}', style: kDim),
                          ]),
                        ),
                      );
                    },
                  ),
          ),
        ),
      ]);
}
