import 'package:flutter/material.dart';

class K {
  static const bg = Color(0xFF0B1020);
  static const card = Color(0xFF141B30);
  static const gold = Color(0xFFE8C26B);
  static const mint = Color(0xFF4ADE9A);
  static const rose = Color(0xFFFF6B7A);
  static const dim = Color(0xFF8B94AD);
  static const glass = Color(0x14FFFFFF);
  static const line = Color(0x1FFFFFFF);
}

const kDim = TextStyle(color: K.dim, fontSize: 13);
const kH = TextStyle(fontSize: 18, fontWeight: FontWeight.w700);

final tick = ValueNotifier<int>(0);
void refresh() => tick.value++;

const dayNames = ['শনি', 'রবি', 'সোম', 'মঙ্গল', 'বুধ', 'বৃহ', 'শুক্র'];
const monthNames = ['জানুয়ারি', 'ফেব্রুয়ারি', 'মার্চ', 'এপ্রিল', 'মে', 'জুন', 'জুলাই', 'আগস্ট', 'সেপ্টেম্বর', 'অক্টোবর', 'নভেম্বর', 'ডিসেম্বর'];
const monthShort = ['জানু', 'ফেব্রু', 'মার্চ', 'এপ্রিল', 'মে', 'জুন', 'জুলাই', 'আগস্ট', 'সেপ্টে', 'অক্টো', 'নভে', 'ডিসে'];

String bn(Object v) {
  const e = '0123456789', b = '০১২৩৪৫৬৭৮৯';
  var s = v.toString();
  for (var i = 0; i < 10; i++) {
    s = s.replaceAll(e[i], b[i]);
  }
  return s;
}

String taka(num v) {
  final g = v.round().toString().replaceAllMapped(RegExp(r'\B(?=(\d{3})+(?!\d))'), (m) => ',');
  return '৳${bn(g)}';
}

String ym(DateTime d) => '${d.year}-${d.month.toString().padLeft(2, '0')}';
String ymd(DateTime d) => '${ym(d)}-${d.day.toString().padLeft(2, '0')}';
String monthLabel(DateTime d) => '${monthNames[d.month - 1]} ${bn(d.year)}';
String todayWd() => ['সোম', 'মঙ্গল', 'বুধ', 'বৃহ', 'শুক্র', 'শনি', 'রবি'][DateTime.now().weekday - 1];

class Live<T> extends StatelessWidget {
  final Future<T> Function() load;
  final Widget Function(BuildContext, T) builder;
  const Live({super.key, required this.load, required this.builder});
  @override
  Widget build(BuildContext context) => ValueListenableBuilder<int>(
        valueListenable: tick,
        builder: (_, __, ___) => FutureBuilder<T>(
          future: load(),
          builder: (ctx, s) => s.hasData
              ? builder(ctx, s.data as T)
              : const Center(child: CircularProgressIndicator(color: K.gold)),
        ),
      );
}

class Glass extends StatelessWidget {
  final Widget child;
  final EdgeInsets pad;
  final VoidCallback? onTap;
  final Gradient? grad;
  const Glass({super.key, required this.child, this.pad = const EdgeInsets.all(16), this.onTap, this.grad});
  @override
  Widget build(BuildContext c) => Container(
        decoration: BoxDecoration(
          color: grad == null ? K.glass : null,
          gradient: grad,
          borderRadius: BorderRadius.circular(22),
          border: Border.all(color: K.line),
        ),
        child: Material(
          color: Colors.transparent,
          child: InkWell(
            borderRadius: BorderRadius.circular(22),
            onTap: onTap,
            child: Padding(padding: pad, child: child),
          ),
        ),
      );
}

class GoldBtn extends StatelessWidget {
  final String label;
  final VoidCallback onTap;
  const GoldBtn({super.key, required this.label, required this.onTap});
  @override
  Widget build(BuildContext c) => Container(
        width: double.infinity,
        decoration: BoxDecoration(
          gradient: const LinearGradient(colors: [Color(0xFFF6DE97), K.gold, Color(0xFFC9A04A)]),
          borderRadius: BorderRadius.circular(18),
        ),
        child: Material(
          color: Colors.transparent,
          child: InkWell(
            borderRadius: BorderRadius.circular(18),
            onTap: onTap,
            child: Padding(
              padding: const EdgeInsets.symmetric(vertical: 15),
              child: Center(child: Text(label, style: const TextStyle(color: K.bg, fontWeight: FontWeight.w800, fontSize: 16))),
            ),
          ),
        ),
      );
}

Widget pill(String t, Color col) => Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
      decoration: BoxDecoration(color: col.withAlpha(40), borderRadius: BorderRadius.circular(20)),
      child: Text(t, style: TextStyle(color: col, fontSize: 12, fontWeight: FontWeight.w700)),
    );

Widget head(String t, {Widget? trail}) => Padding(
      padding: const EdgeInsets.fromLTRB(20, 20, 20, 12),
      child: Row(children: [
        Expanded(child: Text(t, style: const TextStyle(fontSize: 26, fontWeight: FontWeight.w800))),
        if (trail != null) trail,
      ]),
    );

Widget field(TextEditingController t, String l, {TextInputType? kb}) => Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: TextField(
        controller: t,
        keyboardType: kb,
        decoration: InputDecoration(
          labelText: l,
          filled: true,
          fillColor: K.glass,
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: BorderSide.none),
        ),
      ),
    );

Widget empty(IconData i, String t) => Center(
      child: Column(mainAxisSize: MainAxisSize.min, children: [
        Icon(i, size: 56, color: K.line),
        const SizedBox(height: 12),
        Text(t, style: kDim),
      ]),
    );

Future<void> sheet(BuildContext c, Widget Function(BuildContext) b) => showModalBottomSheet(
      context: c,
      isScrollControlled: true,
      backgroundColor: K.card,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(28))),
      builder: (ctx) => Padding(
        padding: EdgeInsets.fromLTRB(20, 22, 20, 22 + MediaQuery.of(ctx).viewInsets.bottom),
        child: SingleChildScrollView(child: b(ctx)),
      ),
    );

Future<bool> confirm(BuildContext c, String msg) async =>
    (await showDialog<bool>(
      context: c,
      builder: (d) => AlertDialog(
        backgroundColor: K.card,
        title: Text(msg, style: kH),
        actions: [
          TextButton(onPressed: () => Navigator.pop(d, false), child: const Text('না')),
          TextButton(onPressed: () => Navigator.pop(d, true), child: const Text('হ্যাঁ', style: TextStyle(color: K.rose))),
        ],
      ),
    )) ??
    false;
