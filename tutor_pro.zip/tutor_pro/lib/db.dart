import 'package:path/path.dart';
import 'package:sqflite/sqflite.dart';

class DB {
  static Database? _db;

  static Future<Database> get db async => _db ??= await openDatabase(
        join(await getDatabasesPath(), 'tutor_pro.db'),
        version: 1,
        onCreate: (d, v) async {
          await d.execute(
              'CREATE TABLE students(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, cls TEXT, phone TEXT, subjects TEXT, days TEXT, fee REAL DEFAULT 0)');
          await d.execute(
              'CREATE TABLE payments(id INTEGER PRIMARY KEY AUTOINCREMENT, studentId INTEGER NOT NULL, amount REAL NOT NULL, month TEXT NOT NULL, date TEXT NOT NULL)');
          await d.execute(
              'CREATE TABLE lessons(id INTEGER PRIMARY KEY AUTOINCREMENT, studentId INTEGER NOT NULL, date TEXT NOT NULL, topic TEXT, homework TEXT)');
        },
      );

  static Future<List<Map<String, dynamic>>> q(String sql, [List<Object?>? a]) async =>
      (await db).rawQuery(sql, a);

  static Future<int> ins(String t, Map<String, Object?> v) async => (await db).insert(t, v);

  static Future<int> upd(String t, Map<String, Object?> v, int id) async =>
      (await db).update(t, v, where: 'id=?', whereArgs: [id]);

  static Future<void> del(String t, int id) async {
    final d = await db;
    await d.delete(t, where: 'id=?', whereArgs: [id]);
    if (t == 'students') {
      await d.delete('payments', where: 'studentId=?', whereArgs: [id]);
      await d.delete('lessons', where: 'studentId=?', whereArgs: [id]);
    }
  }
}
